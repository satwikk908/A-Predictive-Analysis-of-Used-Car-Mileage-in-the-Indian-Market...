import streamlit as st
import pandas as pd
import pickle
import numpy as np

# --- 1. Load the Model and Scaler (Fast Loading) ---
# This part loads your saved model and scaler files.
@st.cache_resource
def load_model():
    try:
        with open('indian_model.pkl', 'rb') as file:
            model = pickle.load(file)
        return model
    except Exception as e:
        st.error(f"Error loading model: {e}")
        return None

@st.cache_resource
def load_scaler():
    try:
        with open('scaler.pkl', 'rb') as file:
            scaler = pickle.load(file)
        return scaler
    except Exception as e:
        st.error(f"Error loading scaler: {e}")
        return None

model = load_model()
scaler = load_scaler()

# --- 2. Show the Title and Sidebar Inputs ---
# MINIMALIST UX: A cleaner, simpler title and instruction.
st.title('Car Mileage Predictor')
st.write("Enter your car's details in the sidebar to get a mileage prediction.")


st.sidebar.header('User Input Features')
vehicle_age = st.sidebar.slider('Vehicle Age (Years)', 1, 20, 5)
km_driven = st.sidebar.slider('Kilometers Driven', 1000, 500000, 50000)
engine = st.sidebar.slider('Engine (CC)', 600, 5000, 1200)
max_power = st.sidebar.slider('Max Power (bhp)', 30.0, 400.0, 80.0)

# --- FUNCTIONAL FIX: Added 8 and 9 back to the options ---
seats = st.sidebar.selectbox('Number of Seats', (4, 5, 6, 7, 8, 9), index=1)
fuel_type = st.sidebar.selectbox('Fuel Type', ('Diesel', 'Petrol'))
seller_type = st.sidebar.selectbox('Seller Type', ('Individual', 'Dealer', 'Trustmark Dealer'))
transmission_type = st.sidebar.selectbox('Transmission Type', ('Manual', 'Automatic'))


# --- 3. Prediction Logic ---
# This part runs when you click the "Predict" button.
if st.sidebar.button('Predict Mileage'):
    if model is not None and scaler is not None:
        
        # 3.1: Create a dictionary of all features the model needs
        # --- FUNCTIONAL FIX: Added 'seats_8' and 'seats_9' back in ---
        input_features = {
            'vehicle_age': vehicle_age,
            'km_driven': km_driven,
            'engine': engine,
            'max_power': max_power,
            
            'fuel_type_Petrol': 0,
            
            'seller_type_Individual': 0,
            'seller_type_Trustmark Dealer': 0,
            
            'transmission_type_Manual': 0,
            
            'seats_2': 0,
            'seats_4': 0,
            'seats_5': 0,
            'seats_6': 0,
            'seats_7': 0,
            'seats_8': 0,  # <-- Added back
            'seats_9': 0   # <-- Added back
        }
        
        # 3.2: Set the 0 or 1 values based on your choices
        if fuel_type == 'Petrol':
            input_features['fuel_type_Petrol'] = 1
        if seller_type == 'Individual':
            input_features['seller_type_Individual'] = 1
        elif seller_type == 'Trustmark Dealer':
            input_features['seller_type_Trustmark Dealer'] = 1
        if transmission_type == 'Manual':
            input_features['transmission_type_Manual'] = 1
            
        seat_col_name = f"seats_{seats}"
        if seat_col_name in input_features:
            input_features[seat_col_name] = 1
            
        # 3.3: Define the exact feature order the model expects
        # --- FUNCTIONAL FIX: Added 'seats_8' and 'seats_9' to the order ---
        feature_order = [
            'vehicle_age', 'km_driven', 'engine', 'max_power',
            'fuel_type_Petrol', 'seller_type_Individual', 
            'seller_type_Trustmark Dealer', 'transmission_type_Manual',
            'seats_2', 'seats_4', 'seats_5', 'seats_6', 'seats_7',
            'seats_8', # <-- Added back
            'seats_9'  # <-- Added back
        ]
        
        input_df = pd.DataFrame([input_features])
        input_df = input_df[feature_order]

        # 3.4: Scale the data and make the prediction
        try:
            input_scaled = scaler.transform(input_df)
            prediction = model.predict(input_scaled)
            
            # 3.5: Display the final prediction
            # --- MINIMALIST UX: Use st.metric for a clean output ---
            st.metric(label="Predicted Mileage", value=f"{prediction[0]:.2f} kmpl")

        except Exception as e:
            st.error(f"An error occurred: {e}")
    else:
        st.error("Model or Scaler not loaded. Please check the files.")

else:
    # --- MINIMALIST UX: Simpler info message ---
    st.info('Please enter car details in the sidebar to predict mileage.')