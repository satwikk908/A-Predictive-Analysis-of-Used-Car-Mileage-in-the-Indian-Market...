# 🚗 Modern Indian Car Mileage Predictor

This is a Streamlit web application that predicts the mileage (in kmpl) of a modern Indian used car. This project was built for an AAT (Automobile + Machine Learning) assignment.

The application uses a Random Forest Regressor model trained on a real-world dataset from **CarDekho**, which was cleaned and processed from its raw text format.

---

## 🛠️ Project Methodology

This project was a complete end-to-end machine learning workflow:

### 1. Data Cleaning (Data Preprocessing)
The raw dataset was "messy" and required significant cleaning. Key steps included:
* **Mileage:** Standardized by removing 'kmpkg' (CNG/LPG) cars and converting the 'kmpl' text (e.g., "18.5 kmpl") into a number (`18.5`).
* **Engine:** Extracted the numeric value from text (e.g., "1197 CC" -> `1197`).
* **Max Power:** Extracted the numeric value from text (e.g., "89.84 bhp" -> `89.84`).
* **Missing Values:** Filled all missing numeric values using the column's mean (average).

### 2. Feature Engineering
* **Categorical Data:** Converted text columns like `fuel_type`, `transmission_type`, and `seller_type` into numeric (0/1) columns using One-Hot Encoding.

### 3. Model Training & Analysis
* **Baseline Model:** A `LinearRegression` model was trained to establish a baseline score.
* **Final Model:** A `RandomForestRegressor` model was trained, which achieved a significantly higher $R^2$ score (over 90% accuracy). This proved it was far superior for this complex, real-world data.
* **Feature Scaling:** A `StandardScaler` was used to normalize all features, improving model performance.

---

## 📂 Project Files

* **`app.py`**: The main Python script that runs the Streamlit web app.
* **`indian_model.pkl`**: The saved, pre-trained Random Forest model.
* **`scaler.pkl`**: The saved `StandardScaler` used to normalize the data.
* **`requirements.txt`**: A list of all Python libraries needed to run the app.
* **`README.md`**: This file!

---

## 🏃 How to Run This Project Locally

**1. Clone the repository (or download the files) into a folder.**

**2. Navigate to the project directory in your terminal:**
```bash
cd path/to/your/cardekho/folder